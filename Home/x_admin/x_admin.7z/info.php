<p><a href="index.php">Home</a></p>

<?php
	phpinfo();
?>

<style>
body {
    background-color: #444;
}
p {
    font-family: sans-serif;
}

a {
    color: #00C;
    text-decoration: none;
}

a:visited {
    color: #00C;
}
</style>