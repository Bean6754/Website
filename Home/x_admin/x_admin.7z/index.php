<!DOCTYPE html>
<html lang="en-GB">
<head>
    <?php
		include('inc/head.php');
	?>
    <title>HAL 9000</title>
</head>
<body>
    <div id="header"><h1>Welcome</h1></div>
    <?php
        include('inc/desktop.php');
    ?>
    <h1 style="text-align: center;"><img src="img/hal_9000.jpg" alt="HAL 9000" style="border-radius: 5%;"></h1>
</body>
</html>