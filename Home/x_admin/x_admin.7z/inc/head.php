<link rel="stylesheet" type="text/css" href="/x_admin/css/global.css">
    <script src="/x_admin/js/jquery.min.js"></script>
    <script src="/x_admin/js/jquery-ui.min.js"></script>