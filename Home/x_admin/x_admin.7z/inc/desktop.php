<script>
    $( function() {
        $( "#moveable_desktop" ).draggable();
    } );
    
    $( function() {
        $( "#moveable_php" ).draggable();
    } );
    
    $( function() {
        $( "#moveable_overseer" ).draggable();
    } );

    $( function() {
        $( "#moveable_duck" ).draggable();
    } );
</script>

<style>
    .button {
        padding-right: 16px;
    }
    .button:hover {
        opacity: 0.8;
        filter: alpha(opacity=80); /* For IE8 and earlier */
    }
    .button_img {
        border-radius: 25%;
        border: 1px solid #222222;
    }
</style>

<div id="desktop">
    <a href="index.php" id="moveable_desktop" class="button">
        <!--
            Home Page
        -->
        <img class="button_img" src="img/icons/desktop.jpg" width="100" height="100">
    </a>
    <a href="info.php" id="moveable_php" class="button">
        <!--
            PHP Info Page
        -->
        <img class="button_img" src="img/icons/php.png" width="100" height="100">
    </a>
    <a href="overseer/index.php" id="moveable_overseer" class="button">
        <!--
            Overseer Page
        -->
        <img class="button_img" src="img/icons/server.png" width="100" height="100">
    </a>
    <a href="https://enersys-emea.okta.com" target="_blank" id="moveable_duck" class="button">
        <!--
            DuckDuckGo
        -->
        <img class="button_img" src="img/icons/duck.png" width="100" height="100">
    </a>
</div>